var NumberArray:[Double] = [1,-1,1.1,3.2,-4,5]
var length = NumberArray.count
var plusDouble:[Double]
var minus:[Double]
var plusInt:[Double]

while (length > 0){
    let number = NumberArray[length]
    let isInteger = floor(number) == number
    if number > 0 {
        if isInteger = true{
            plusInt.append(number)
        } else {
            plusDouble.append(number)
        }
    } else {
        minus.append(number)
    }
}